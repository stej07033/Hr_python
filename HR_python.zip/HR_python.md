```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

print("Libraries imported successfully!")
```

    Libraries imported successfully!
    


```python
df = pd.read_csv("HR DATA_Excel 2.csv")

print("Dataset loaded successfully!")
```

    Dataset loaded successfully!
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Attrition</th>
      <th>Business Travel</th>
      <th>CF_age band</th>
      <th>CF_attrition label</th>
      <th>Department</th>
      <th>Education Field</th>
      <th>emp no</th>
      <th>Employee Number</th>
      <th>Gender</th>
      <th>Job Role</th>
      <th>...</th>
      <th>Performance Rating</th>
      <th>Relationship Satisfaction</th>
      <th>Standard Hours</th>
      <th>Stock Option Level</th>
      <th>Total Working Years</th>
      <th>Work Life Balance</th>
      <th>Years At Company</th>
      <th>Years In Current Role</th>
      <th>Years Since Last Promotion</th>
      <th>Years With Curr Manager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>35 - 44</td>
      <td>Ex-Employees</td>
      <td>Sales</td>
      <td>Life Sciences</td>
      <td>STAFF-1</td>
      <td>1</td>
      <td>Female</td>
      <td>Sales Executive</td>
      <td>...</td>
      <td>3</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>45 - 54</td>
      <td>Current Employees</td>
      <td>R&amp;D</td>
      <td>Life Sciences</td>
      <td>STAFF-2</td>
      <td>2</td>
      <td>Male</td>
      <td>Research Scientist</td>
      <td>...</td>
      <td>4</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>35 - 44</td>
      <td>Ex-Employees</td>
      <td>R&amp;D</td>
      <td>Other</td>
      <td>STAFF-4</td>
      <td>4</td>
      <td>Male</td>
      <td>Laboratory Technician</td>
      <td>...</td>
      <td>3</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>25 - 34</td>
      <td>Current Employees</td>
      <td>R&amp;D</td>
      <td>Life Sciences</td>
      <td>STAFF-5</td>
      <td>5</td>
      <td>Female</td>
      <td>Research Scientist</td>
      <td>...</td>
      <td>3</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>25 - 34</td>
      <td>Current Employees</td>
      <td>R&amp;D</td>
      <td>Medical</td>
      <td>STAFF-7</td>
      <td>7</td>
      <td>Male</td>
      <td>Laboratory Technician</td>
      <td>...</td>
      <td>3</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 44 columns</p>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Attrition</th>
      <th>Business Travel</th>
      <th>CF_age band</th>
      <th>CF_attrition label</th>
      <th>Department</th>
      <th>Education Field</th>
      <th>emp no</th>
      <th>Employee Number</th>
      <th>Gender</th>
      <th>Job Role</th>
      <th>...</th>
      <th>Performance Rating</th>
      <th>Relationship Satisfaction</th>
      <th>Standard Hours</th>
      <th>Stock Option Level</th>
      <th>Total Working Years</th>
      <th>Work Life Balance</th>
      <th>Years At Company</th>
      <th>Years In Current Role</th>
      <th>Years Since Last Promotion</th>
      <th>Years With Curr Manager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1465</th>
      <td>Yes</td>
      <td>Non-Travel</td>
      <td>25 - 34</td>
      <td>Ex-Employees</td>
      <td>R&amp;D</td>
      <td>Technical Degree</td>
      <td>STAFF-1905</td>
      <td>1905</td>
      <td>Male</td>
      <td>Research Scientist</td>
      <td>...</td>
      <td>4</td>
      <td>2</td>
      <td>80</td>
      <td>1</td>
      <td>5</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1466</th>
      <td>Yes</td>
      <td>Travel_Frequently</td>
      <td>25 - 34</td>
      <td>Ex-Employees</td>
      <td>R&amp;D</td>
      <td>Life Sciences</td>
      <td>STAFF-1868</td>
      <td>1868</td>
      <td>Male</td>
      <td>Research Scientist</td>
      <td>...</td>
      <td>4</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1467</th>
      <td>Yes</td>
      <td>Travel_Frequently</td>
      <td>35 - 44</td>
      <td>Ex-Employees</td>
      <td>Sales</td>
      <td>Other</td>
      <td>STAFF-1667</td>
      <td>1667</td>
      <td>Male</td>
      <td>Sales Executive</td>
      <td>...</td>
      <td>4</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>13</td>
      <td>4</td>
      <td>11</td>
      <td>9</td>
      <td>6</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1468</th>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>Under 25</td>
      <td>Ex-Employees</td>
      <td>R&amp;D</td>
      <td>Life Sciences</td>
      <td>STAFF-1878</td>
      <td>1878</td>
      <td>Male</td>
      <td>Research Scientist</td>
      <td>...</td>
      <td>4</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>Under 25</td>
      <td>Ex-Employees</td>
      <td>Sales</td>
      <td>Life Sciences</td>
      <td>STAFF-1702</td>
      <td>1702</td>
      <td>Male</td>
      <td>Sales Representative</td>
      <td>...</td>
      <td>4</td>
      <td>2</td>
      <td>80</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 44 columns</p>
</div>



## Check the dataset


```python
print("Dataset shape:", df.shape)

print("\nColumn names:")
print(df.columns.tolist())

print("\nData types:")
print(df.dtypes)

print("\nMissing values:")
print(df.isnull().sum())
```

    Dataset shape: (1470, 44)
    
    Column names:
    ['Attrition', 'Business Travel', 'CF_age band', 'CF_attrition label', 'Department', 'Education Field', 'emp no', 'Employee Number', 'Gender', 'Job Role', 'Marital Status', 'Over Time', 'Over18', 'Training Times Last Year', '-2', '0', 'Age', 'CF_attrition count', 'CF_attrition counts', 'CF_attrition rate', 'CF_current Employee', 'Daily Rate', 'Distance From Home', 'Education', 'Employee Count', 'Environment Satisfaction', 'Hourly Rate', 'Job Involvement', 'Job Level', 'Job Satisfaction', 'Monthly Income', 'Monthly Rate', 'Num Companies Worked', 'Percent Salary Hike', 'Performance Rating', 'Relationship Satisfaction', 'Standard Hours', 'Stock Option Level', 'Total Working Years', 'Work Life Balance', 'Years At Company', 'Years In Current Role', 'Years Since Last Promotion', 'Years With Curr Manager']
    
    Data types:
    Attrition                      object
    Business Travel                object
    CF_age band                    object
    CF_attrition label             object
    Department                     object
    Education Field                object
    emp no                         object
    Employee Number                 int64
    Gender                         object
    Job Role                       object
    Marital Status                 object
    Over Time                      object
    Over18                         object
    Training Times Last Year        int64
    -2                              int64
    0                               int64
    Age                             int64
    CF_attrition count              int64
    CF_attrition counts           float64
    CF_attrition rate               int64
    CF_current Employee             int64
    Daily Rate                      int64
    Distance From Home              int64
    Education                      object
    Employee Count                  int64
    Environment Satisfaction        int64
    Hourly Rate                     int64
    Job Involvement                 int64
    Job Level                       int64
    Job Satisfaction                int64
    Monthly Income                  int64
    Monthly Rate                    int64
    Num Companies Worked            int64
    Percent Salary Hike             int64
    Performance Rating              int64
    Relationship Satisfaction       int64
    Standard Hours                  int64
    Stock Option Level              int64
    Total Working Years             int64
    Work Life Balance               int64
    Years At Company                int64
    Years In Current Role           int64
    Years Since Last Promotion      int64
    Years With Curr Manager         int64
    dtype: object
    
    Missing values:
    Attrition                        0
    Business Travel                  0
    CF_age band                      0
    CF_attrition label               0
    Department                       0
    Education Field                  0
    emp no                           0
    Employee Number                  0
    Gender                           0
    Job Role                         0
    Marital Status                   0
    Over Time                        0
    Over18                           0
    Training Times Last Year         0
    -2                               0
    0                                0
    Age                              0
    CF_attrition count               0
    CF_attrition counts           1233
    CF_attrition rate                0
    CF_current Employee              0
    Daily Rate                       0
    Distance From Home               0
    Education                        0
    Employee Count                   0
    Environment Satisfaction         0
    Hourly Rate                      0
    Job Involvement                  0
    Job Level                        0
    Job Satisfaction                 0
    Monthly Income                   0
    Monthly Rate                     0
    Num Companies Worked             0
    Percent Salary Hike              0
    Performance Rating               0
    Relationship Satisfaction        0
    Standard Hours                   0
    Stock Option Level               0
    Total Working Years              0
    Work Life Balance                0
    Years At Company                 0
    Years In Current Role            0
    Years Since Last Promotion       0
    Years With Curr Manager          0
    dtype: int64
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employee Number</th>
      <th>Training Times Last Year</th>
      <th>-2</th>
      <th>0</th>
      <th>Age</th>
      <th>CF_attrition count</th>
      <th>CF_attrition counts</th>
      <th>CF_attrition rate</th>
      <th>CF_current Employee</th>
      <th>Daily Rate</th>
      <th>...</th>
      <th>Performance Rating</th>
      <th>Relationship Satisfaction</th>
      <th>Standard Hours</th>
      <th>Stock Option Level</th>
      <th>Total Working Years</th>
      <th>Work Life Balance</th>
      <th>Years At Company</th>
      <th>Years In Current Role</th>
      <th>Years Since Last Promotion</th>
      <th>Years With Curr Manager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.0</td>
      <td>1470.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>237.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>...</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1024.865306</td>
      <td>2.799320</td>
      <td>-2.0</td>
      <td>0.0</td>
      <td>36.923810</td>
      <td>0.161224</td>
      <td>1.0</td>
      <td>0.161224</td>
      <td>0.838776</td>
      <td>802.485714</td>
      <td>...</td>
      <td>3.153741</td>
      <td>2.712245</td>
      <td>80.0</td>
      <td>0.793878</td>
      <td>11.279592</td>
      <td>2.761224</td>
      <td>7.008163</td>
      <td>4.229252</td>
      <td>2.187755</td>
      <td>4.123129</td>
    </tr>
    <tr>
      <th>std</th>
      <td>602.024335</td>
      <td>1.289271</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9.135373</td>
      <td>0.367863</td>
      <td>0.0</td>
      <td>0.367863</td>
      <td>0.367863</td>
      <td>403.509100</td>
      <td>...</td>
      <td>0.360824</td>
      <td>1.081209</td>
      <td>0.0</td>
      <td>0.852077</td>
      <td>7.780782</td>
      <td>0.706476</td>
      <td>6.126525</td>
      <td>3.623137</td>
      <td>3.222430</td>
      <td>3.568136</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>-2.0</td>
      <td>0.0</td>
      <td>18.000000</td>
      <td>0.000000</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>102.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>80.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>491.250000</td>
      <td>2.000000</td>
      <td>-2.0</td>
      <td>0.0</td>
      <td>30.000000</td>
      <td>0.000000</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>465.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>80.0</td>
      <td>0.000000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1020.500000</td>
      <td>3.000000</td>
      <td>-2.0</td>
      <td>0.0</td>
      <td>36.000000</td>
      <td>0.000000</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>802.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>80.0</td>
      <td>1.000000</td>
      <td>10.000000</td>
      <td>3.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1555.750000</td>
      <td>3.000000</td>
      <td>-2.0</td>
      <td>0.0</td>
      <td>43.000000</td>
      <td>0.000000</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1157.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>4.000000</td>
      <td>80.0</td>
      <td>1.000000</td>
      <td>15.000000</td>
      <td>3.000000</td>
      <td>9.000000</td>
      <td>7.000000</td>
      <td>3.000000</td>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2068.000000</td>
      <td>6.000000</td>
      <td>-2.0</td>
      <td>0.0</td>
      <td>60.000000</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1499.000000</td>
      <td>...</td>
      <td>4.000000</td>
      <td>4.000000</td>
      <td>80.0</td>
      <td>3.000000</td>
      <td>40.000000</td>
      <td>4.000000</td>
      <td>40.000000</td>
      <td>18.000000</td>
      <td>15.000000</td>
      <td>17.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 31 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1470 entries, 0 to 1469
    Data columns (total 44 columns):
     #   Column                      Non-Null Count  Dtype  
    ---  ------                      --------------  -----  
     0   Attrition                   1470 non-null   object 
     1   Business Travel             1470 non-null   object 
     2   CF_age band                 1470 non-null   object 
     3   CF_attrition label          1470 non-null   object 
     4   Department                  1470 non-null   object 
     5   Education Field             1470 non-null   object 
     6   emp no                      1470 non-null   object 
     7   Employee Number             1470 non-null   int64  
     8   Gender                      1470 non-null   object 
     9   Job Role                    1470 non-null   object 
     10  Marital Status              1470 non-null   object 
     11  Over Time                   1470 non-null   object 
     12  Over18                      1470 non-null   object 
     13  Training Times Last Year    1470 non-null   int64  
     14  -2                          1470 non-null   int64  
     15  0                           1470 non-null   int64  
     16  Age                         1470 non-null   int64  
     17  CF_attrition count          1470 non-null   int64  
     18  CF_attrition counts         237 non-null    float64
     19  CF_attrition rate           1470 non-null   int64  
     20  CF_current Employee         1470 non-null   int64  
     21  Daily Rate                  1470 non-null   int64  
     22  Distance From Home          1470 non-null   int64  
     23  Education                   1470 non-null   object 
     24  Employee Count              1470 non-null   int64  
     25  Environment Satisfaction    1470 non-null   int64  
     26  Hourly Rate                 1470 non-null   int64  
     27  Job Involvement             1470 non-null   int64  
     28  Job Level                   1470 non-null   int64  
     29  Job Satisfaction            1470 non-null   int64  
     30  Monthly Income              1470 non-null   int64  
     31  Monthly Rate                1470 non-null   int64  
     32  Num Companies Worked        1470 non-null   int64  
     33  Percent Salary Hike         1470 non-null   int64  
     34  Performance Rating          1470 non-null   int64  
     35  Relationship Satisfaction   1470 non-null   int64  
     36  Standard Hours              1470 non-null   int64  
     37  Stock Option Level          1470 non-null   int64  
     38  Total Working Years         1470 non-null   int64  
     39  Work Life Balance           1470 non-null   int64  
     40  Years At Company            1470 non-null   int64  
     41  Years In Current Role       1470 non-null   int64  
     42  Years Since Last Promotion  1470 non-null   int64  
     43  Years With Curr Manager     1470 non-null   int64  
    dtypes: float64(1), int64(30), object(13)
    memory usage: 505.4+ KB
    

# Understand the data


```python
print("Attrition count:")
print(df["Attrition"].value_counts())

print("\nAttrition percentage:")
print(
    df["Attrition"]
    .value_counts(normalize=True)
    .mul(100)
    .round(2)
)
```

    Attrition count:
    Attrition
    No     1233
    Yes     237
    Name: count, dtype: int64
    
    Attrition percentage:
    Attrition
    No     83.88
    Yes    16.12
    Name: proportion, dtype: float64
    

## Total employees,
## Employees left,
## Attrition rate


```python
total_employees = len(df)

employees_left = np.sum(df["Attrition"] == "Yes")

attrition_rate = np.divide(
    employees_left,
    total_employees
) * 100

print("Total employees:", total_employees)
print("Employees left:", employees_left)
print("Attrition rate:", round(attrition_rate, 2), "%")
```

    Total employees: 1470
    Employees left: 237
    Attrition rate: 16.12 %
    

## Clean the dataset


```python
print("Missing values:")
print(df.isnull().sum().sort_values(ascending=False).head(15))

print("\nDuplicate rows:", df.duplicated().sum())
```

    Missing values:
    CF_attrition counts          1233
    Attrition                       0
    Education                       0
    Environment Satisfaction        0
    Hourly Rate                     0
    Job Involvement                 0
    Job Level                       0
    Job Satisfaction                0
    Monthly Income                  0
    Monthly Rate                    0
    Num Companies Worked            0
    Percent Salary Hike             0
    Performance Rating              0
    Relationship Satisfaction       0
    Standard Hours                  0
    dtype: int64
    
    Duplicate rows: 0
    


```python
hr = df.copy()

# Remove exact duplicate rows, if any
hr = hr.drop_duplicates()

# Check missing values in important analysis columns
important_columns = [
    "Attrition",
    "Department",
    "Gender",
    "Age",
    "Monthly Income",
    "Job Role",
    "Over Time",
    "Job Satisfaction"
]

print(hr[important_columns].isnull().sum())
```

    Attrition           0
    Department          0
    Gender              0
    Age                 0
    Monthly Income      0
    Job Role            0
    Over Time           0
    Job Satisfaction    0
    dtype: int64
    

## Analyze attrition by department


```python
department_analysis = hr.groupby("Department").agg(
    Total_Employees=("Attrition", "size"),
    Employees_Left=("Attrition", lambda x: (x == "Yes").sum())
)

department_analysis["Attrition_Rate"] = (
    department_analysis["Employees_Left"]
    / department_analysis["Total_Employees"] * 100
).round(2)

display(department_analysis.sort_values(
    "Attrition_Rate", ascending=False
))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total_Employees</th>
      <th>Employees_Left</th>
      <th>Attrition_Rate</th>
    </tr>
    <tr>
      <th>Department</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Sales</th>
      <td>446</td>
      <td>92</td>
      <td>20.63</td>
    </tr>
    <tr>
      <th>HR</th>
      <td>63</td>
      <td>12</td>
      <td>19.05</td>
    </tr>
    <tr>
      <th>R&amp;D</th>
      <td>961</td>
      <td>133</td>
      <td>13.84</td>
    </tr>
  </tbody>
</table>
</div>



```python
plt.figure(figsize=(9, 5))

sns.barplot(
    data=department_analysis.reset_index(),
    x="Department",
    y="Attrition_Rate"
)

plt.title("Employee Attrition Rate by Department")
plt.xlabel("Department")
plt.ylabel("Attrition Rate (%)")
plt.tight_layout()
plt.show()
```


    
![png](output_17_0.png)
    


## Analyze attrition by overtime


```python
overtime_analysis = hr.groupby("Over Time").agg(
    Total_Employees=("Attrition", "size"),
    Employees_Left=("Attrition", lambda x: (x == "Yes").sum())
)

overtime_analysis["Attrition_Rate"] = (
    overtime_analysis["Employees_Left"]
    / overtime_analysis["Total_Employees"] * 100
).round(2)

display(overtime_analysis)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total_Employees</th>
      <th>Employees_Left</th>
      <th>Attrition_Rate</th>
    </tr>
    <tr>
      <th>Over Time</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>No</th>
      <td>1054</td>
      <td>110</td>
      <td>10.44</td>
    </tr>
    <tr>
      <th>Yes</th>
      <td>416</td>
      <td>127</td>
      <td>30.53</td>
    </tr>
  </tbody>
</table>
</div>



```python
plt.figure(figsize=(7, 5))

sns.barplot(
    data=hr,
    x="Over Time",
    y=hr["Attrition"].eq("Yes").astype(int)
)

plt.title("Overtime and Employee Attrition")
plt.xlabel("Works Overtime")
plt.ylabel("Average Attrition (0 to 1)")
plt.tight_layout()
plt.show()
```


    
![png](output_20_0.png)
    


## Analyze attrition by age


```python
plt.figure(figsize=(10, 6))

sns.histplot(
    data=hr,
    x="Age",
    hue="Attrition",
    bins=20,
    kde=True,
    element="step"
)

plt.title("Age Distribution by Employee Attrition")
plt.xlabel("Employee Age")
plt.ylabel("Number of Employees")
plt.tight_layout()
plt.show()
```


    
![png](output_22_0.png)
    



```python
age_analysis = hr.groupby("Attrition")["Age"].agg(
    ["count", "mean", "median"]
).round(2)

display(age_analysis)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>median</th>
    </tr>
    <tr>
      <th>Attrition</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>No</th>
      <td>1233</td>
      <td>37.56</td>
      <td>36.0</td>
    </tr>
    <tr>
      <th>Yes</th>
      <td>237</td>
      <td>33.61</td>
      <td>32.0</td>
    </tr>
  </tbody>
</table>
</div>


## Analyze monthly salary


```python
salary_analysis = hr.groupby("Attrition")["Monthly Income"].agg(
    ["count", "mean", "median", "min", "max"]
).round(2)

display(salary_analysis)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>median</th>
      <th>min</th>
      <th>max</th>
    </tr>
    <tr>
      <th>Attrition</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>No</th>
      <td>1233</td>
      <td>6832.74</td>
      <td>5204.0</td>
      <td>1051</td>
      <td>19999</td>
    </tr>
    <tr>
      <th>Yes</th>
      <td>237</td>
      <td>4787.09</td>
      <td>3202.0</td>
      <td>1009</td>
      <td>19859</td>
    </tr>
  </tbody>
</table>
</div>



```python
plt.figure(figsize=(8, 5))

sns.boxplot(
    data=hr,
    x="Attrition",
    y="Monthly Income"
)

plt.title("Monthly Income vs Employee Attrition")
plt.xlabel("Attrition")
plt.ylabel("Monthly Income")
plt.tight_layout()
plt.show()
```


    
![png](output_26_0.png)
    


## Analyze job satisfaction


```python
satisfaction_analysis = pd.crosstab(
    hr["Job Satisfaction"],
    hr["Attrition"],
    normalize="index"
).mul(100).round(2)

display(satisfaction_analysis)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Attrition</th>
      <th>No</th>
      <th>Yes</th>
    </tr>
    <tr>
      <th>Job Satisfaction</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>76.79</td>
      <td>23.21</td>
    </tr>
    <tr>
      <th>2</th>
      <td>85.56</td>
      <td>14.44</td>
    </tr>
    <tr>
      <th>3</th>
      <td>85.61</td>
      <td>14.39</td>
    </tr>
    <tr>
      <th>4</th>
      <td>85.45</td>
      <td>14.55</td>
    </tr>
  </tbody>
</table>
</div>



```python
satisfaction_analysis.plot(
    kind="bar",
    figsize=(9, 5)
)

plt.title("Attrition by Job Satisfaction")
plt.xlabel("Job Satisfaction Level")
plt.ylabel("Employees (%)")
plt.xticks(rotation=0)
plt.legend(title="Attrition")
plt.tight_layout()
plt.show()
```


    
![png](output_29_0.png)
    


## Analyze attrition by job role


```python
role_analysis = hr.groupby("Job Role").agg(
    Total_Employees=("Attrition", "size"),
    Employees_Left=("Attrition", lambda x: (x == "Yes").sum())
)

role_analysis["Attrition_Rate"] = (
    role_analysis["Employees_Left"]
    / role_analysis["Total_Employees"] * 100
).round(2)

role_analysis = role_analysis.sort_values(
    "Attrition_Rate", ascending=False
)

display(role_analysis)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total_Employees</th>
      <th>Employees_Left</th>
      <th>Attrition_Rate</th>
    </tr>
    <tr>
      <th>Job Role</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Sales Representative</th>
      <td>83</td>
      <td>33</td>
      <td>39.76</td>
    </tr>
    <tr>
      <th>Laboratory Technician</th>
      <td>259</td>
      <td>62</td>
      <td>23.94</td>
    </tr>
    <tr>
      <th>Human Resources</th>
      <td>52</td>
      <td>12</td>
      <td>23.08</td>
    </tr>
    <tr>
      <th>Sales Executive</th>
      <td>326</td>
      <td>57</td>
      <td>17.48</td>
    </tr>
    <tr>
      <th>Research Scientist</th>
      <td>292</td>
      <td>47</td>
      <td>16.10</td>
    </tr>
    <tr>
      <th>Manufacturing Director</th>
      <td>145</td>
      <td>10</td>
      <td>6.90</td>
    </tr>
    <tr>
      <th>Healthcare Representative</th>
      <td>131</td>
      <td>9</td>
      <td>6.87</td>
    </tr>
    <tr>
      <th>Manager</th>
      <td>102</td>
      <td>5</td>
      <td>4.90</td>
    </tr>
    <tr>
      <th>Research Director</th>
      <td>80</td>
      <td>2</td>
      <td>2.50</td>
    </tr>
  </tbody>
</table>
</div>



```python
plt.figure(figsize=(12, 6))

sns.barplot(
    data=role_analysis.reset_index(),
    x="Attrition_Rate",
    y="Job Role"
)

plt.title("Attrition Rate by Job Role")
plt.xlabel("Attrition Rate (%)")
plt.ylabel("Job Role")
plt.tight_layout()
plt.show()
```


    
![png](output_32_0.png)
    


## Use NumPy for numerical analysis


```python
left_income = hr.loc[
    hr["Attrition"] == "Yes", "Monthly Income"
].to_numpy()

stayed_income = hr.loc[
    hr["Attrition"] == "No", "Monthly Income"
].to_numpy()

print("Average income of employees who left:",
      round(np.mean(left_income), 2))

print("Average income of employees who stayed:",
      round(np.mean(stayed_income), 2))

print("Median income of employees who left:",
      np.median(left_income))

print("Median income of employees who stayed:",
      np.median(stayed_income))
```

    Average income of employees who left: 4787.09
    Average income of employees who stayed: 6832.74
    Median income of employees who left: 3202.0
    Median income of employees who stayed: 5204.0
    


```python
numeric_columns = [
    "Age",
    "Monthly Income",
    "Job Satisfaction",
    "Years At Company",
    "Years In Current Role",
    "Years With Curr Manager",
    "Distance From Home"
]

correlation = hr[numeric_columns].corr()

display(correlation.round(2))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Monthly Income</th>
      <th>Job Satisfaction</th>
      <th>Years At Company</th>
      <th>Years In Current Role</th>
      <th>Years With Curr Manager</th>
      <th>Distance From Home</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Age</th>
      <td>1.00</td>
      <td>0.50</td>
      <td>-0.01</td>
      <td>0.31</td>
      <td>0.21</td>
      <td>0.20</td>
      <td>-0.00</td>
    </tr>
    <tr>
      <th>Monthly Income</th>
      <td>0.50</td>
      <td>1.00</td>
      <td>-0.01</td>
      <td>0.51</td>
      <td>0.36</td>
      <td>0.34</td>
      <td>-0.02</td>
    </tr>
    <tr>
      <th>Job Satisfaction</th>
      <td>-0.01</td>
      <td>-0.01</td>
      <td>1.00</td>
      <td>-0.01</td>
      <td>0.00</td>
      <td>-0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>Years At Company</th>
      <td>0.31</td>
      <td>0.51</td>
      <td>-0.01</td>
      <td>1.00</td>
      <td>0.76</td>
      <td>0.77</td>
      <td>0.01</td>
    </tr>
    <tr>
      <th>Years In Current Role</th>
      <td>0.21</td>
      <td>0.36</td>
      <td>0.00</td>
      <td>0.76</td>
      <td>1.00</td>
      <td>0.71</td>
      <td>0.02</td>
    </tr>
    <tr>
      <th>Years With Curr Manager</th>
      <td>0.20</td>
      <td>0.34</td>
      <td>-0.00</td>
      <td>0.77</td>
      <td>0.71</td>
      <td>1.00</td>
      <td>0.01</td>
    </tr>
    <tr>
      <th>Distance From Home</th>
      <td>-0.00</td>
      <td>-0.02</td>
      <td>0.00</td>
      <td>0.01</td>
      <td>0.02</td>
      <td>0.01</td>
      <td>1.00</td>
    </tr>
  </tbody>
</table>
</div>



```python
plt.figure(figsize=(11, 7))

sns.heatmap(
    correlation,
    annot=True,
    cmap="coolwarm",
    fmt=".2f",
    linewidths=0.5
)

plt.title("HR Employee Variables Correlation Heatmap")
plt.tight_layout()
plt.show()
```


    
![png](output_36_0.png)
    


## Create an age-group analysis


```python
conditions = [
    hr["Age"] < 25,
    hr["Age"].between(25, 34),
    hr["Age"].between(35, 44),
    hr["Age"].between(45, 54),
    hr["Age"] >= 55
]

choices = [
    "Under 25",
    "25-34",
    "35-44",
    "45-54",
    "55+"
]

hr["Age Group"] = np.select(
    conditions,
    choices,
    default="Unknown"
)

age_group_analysis = hr.groupby("Age Group").agg(
    Total_Employees=("Attrition", "size"),
    Employees_Left=("Attrition", lambda x: (x == "Yes").sum())
)

age_group_analysis["Attrition_Rate"] = (
    age_group_analysis["Employees_Left"]
    / age_group_analysis["Total_Employees"] * 100
).round(2)

display(age_group_analysis)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total_Employees</th>
      <th>Employees_Left</th>
      <th>Attrition_Rate</th>
    </tr>
    <tr>
      <th>Age Group</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>25-34</th>
      <td>554</td>
      <td>112</td>
      <td>20.22</td>
    </tr>
    <tr>
      <th>35-44</th>
      <td>505</td>
      <td>51</td>
      <td>10.10</td>
    </tr>
    <tr>
      <th>45-54</th>
      <td>245</td>
      <td>25</td>
      <td>10.20</td>
    </tr>
    <tr>
      <th>55+</th>
      <td>69</td>
      <td>11</td>
      <td>15.94</td>
    </tr>
    <tr>
      <th>Under 25</th>
      <td>97</td>
      <td>38</td>
      <td>39.18</td>
    </tr>
  </tbody>
</table>
</div>



```python
import os

os.makedirs("data", exist_ok=True)
os.makedirs("outputs", exist_ok=True)

hr.to_csv("data/cleaned_hr_data.csv", index=False)

print("Cleaned dataset saved successfully!")
```

    Cleaned dataset saved successfully!
    

## Generate a final HR summary report


```python
total_employees = len(hr)
employees_left = (hr["Attrition"] == "Yes").sum()
employees_stayed = (hr["Attrition"] == "No").sum()

overall_attrition = np.mean(
    hr["Attrition"].eq("Yes")
) * 100

print("=" * 45)
print("       HR ATTRITION ANALYSIS REPORT")
print("=" * 45)

print("Total Employees:", total_employees)
print("Employees Left:", employees_left)
print("Employees Stayed:", employees_stayed)
print("Overall Attrition Rate:",
      round(overall_attrition, 2), "%")

print("\nDepartment Analysis:")
print(department_analysis.sort_values(
    "Attrition_Rate", ascending=False
))

print("\nJob Role Analysis:")
print(role_analysis)

print("\nOvertime Analysis:")
print(overtime_analysis)

print("\nSalary Analysis:")
print(salary_analysis)

print("=" * 45)
```

    =============================================
           HR ATTRITION ANALYSIS REPORT
    =============================================
    Total Employees: 1470
    Employees Left: 237
    Employees Stayed: 1233
    Overall Attrition Rate: 16.12 %
    
    Department Analysis:
                Total_Employees  Employees_Left  Attrition_Rate
    Department                                                 
    Sales                   446              92           20.63
    HR                       63              12           19.05
    R&D                     961             133           13.84
    
    Job Role Analysis:
                               Total_Employees  Employees_Left  Attrition_Rate
    Job Role                                                                  
    Sales Representative                    83              33           39.76
    Laboratory Technician                  259              62           23.94
    Human Resources                         52              12           23.08
    Sales Executive                        326              57           17.48
    Research Scientist                     292              47           16.10
    Manufacturing Director                 145              10            6.90
    Healthcare Representative              131               9            6.87
    Manager                                102               5            4.90
    Research Director                       80               2            2.50
    
    Overtime Analysis:
               Total_Employees  Employees_Left  Attrition_Rate
    Over Time                                                 
    No                    1054             110           10.44
    Yes                    416             127           30.53
    
    Salary Analysis:
               count     mean  median   min    max
    Attrition                                     
    No          1233  6832.74  5204.0  1051  19999
    Yes          237  4787.09  3202.0  1009  19859
    =============================================
    


```python

```


```python

```
